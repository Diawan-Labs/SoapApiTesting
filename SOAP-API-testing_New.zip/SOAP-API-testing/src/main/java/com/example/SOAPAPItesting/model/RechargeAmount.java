package com.example.SOAPAPItesting.model;

public enum RechargeAmount {
	HUNDRED(100),
	FIFTY(50),
	TWENTY(20),
	TEN(10);
	int amount;

	private RechargeAmount(int amount) {
		this.amount = amount;
	}
	public int getValue() { return amount; }
	 
	
}
