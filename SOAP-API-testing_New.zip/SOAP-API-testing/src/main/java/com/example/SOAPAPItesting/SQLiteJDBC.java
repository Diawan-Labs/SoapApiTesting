package com.example.SOAPAPItesting;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class SQLiteJDBC {
    Connection c = null;
    Statement stmt = null;

    SQLiteJDBC()  {
        try {
			Class.forName("org.sqlite.JDBC");
			  c = DriverManager.getConnection("jdbc:sqlite:Counter.db");
		        stmt = c.createStatement();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
   
    void updateSeqNo(int sno){
        String sqlQuery1 = "UPDATE  Sequence SET SeqNo="+sno;
        String sqlQuery2 = " Where ID=1";
        String query = sqlQuery1 + sqlQuery2;
        try {
			int i=stmt.executeUpdate(query);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
  
    int getSeqNo()  {
        String sqlQuery1 = "Select SeqNo from Sequence";
        int snumber = 0;
        ResultSet resultSet = null;
		try {
			resultSet = stmt.executeQuery(sqlQuery1);
			snumber=resultSet.getInt(1);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return snumber;
       
    }
   
    void releaseConn() throws SQLException {
        stmt.close();
        c.close();
    }
}