package com.example.SOAPAPItesting.model;

public enum ProjectType {
	Project_Type_1(1),
	Project_Type_2(2),
	Project_Type_3(3),
	Project_Type_4(4),
	Project_Type_5(5);
	
	int ptype;

	 ProjectType(int ptype) {
		this.ptype = ptype;
	}
	public int getValue() { return ptype; }
	
}
