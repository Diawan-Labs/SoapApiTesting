package com.example.SOAPAPItesting;

import java.util.ArrayList;
import java.util.Arrays;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.SOAPAPItesting.model.Counter;
import com.example.SOAPAPItesting.model.Login;
import com.example.SOAPAPItesting.model.ProjectType;
import com.example.SOAPAPItesting.model.RechargeAmount;
import com.example.SOAPAPItesting.model.Vnds;

@Controller
public class MyController {


	SQLiteJDBC slLiteJDBC=new SQLiteJDBC();
	@PostMapping("/dologin")
	public ResponseEntity<String> doLogin(Login login) {
 
		MyHttpClientForLogin myHttpClientForLogin=new MyHttpClientForLogin();
		
		return new ResponseEntity<String>(myHttpClientForLogin.ok2(login), HttpStatus.OK);
	}
	 @GetMapping("/login")
	    public String showForm(Model model) {
		 	
	        Login login = new Login();
	        model.addAttribute("login", login);
	      
	        return "login";
	    }
	 @GetMapping("/host")
	    public String showHostPage(Model model) {
	       Vnds vnds=new Vnds();
	     
	       
	        model.addAttribute("vnds", vnds);
	      
	        
	        ArrayList<ProjectType> projectTypesArrayList=new ArrayList<ProjectType>(Arrays.asList(ProjectType.values()));
	        ArrayList<RechargeAmount> rechargeAmountArrayList=new ArrayList<RechargeAmount>(Arrays.asList(RechargeAmount.values()));
		      
	  
	        model.addAttribute("projectTypesArrayList",projectTypesArrayList);
	        model.addAttribute("rechargeAmountArrayList",rechargeAmountArrayList);
	        model.addAttribute("counter", new Counter());
	        return "host";
	    }
		@PostMapping("/testhostserivce")
		public ResponseEntity<String> testHostService(Vnds vnds) {
			
			
			int snum=slLiteJDBC.getSeqNo();
			vnds.setSe(snum);
			slLiteJDBC.updateSeqNo(snum+1);
			
			System.out.println("vnds::"+vnds);
		//MyHttpClientForHostService httpClientForHostService=new MyHttpClientForHostService();
			
			//return new ResponseEntity<String>(httpClientForHostService.ok2(vnds), HttpStatus.OK);
			
			return new ResponseEntity<String>(vnds.toString(), HttpStatus.OK);
			
		}
}
