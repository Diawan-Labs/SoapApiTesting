package com.example.SOAPAPItesting;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SoapApiTestingApplication {

	public static void main(String[] args) {
		SpringApplication.run(SoapApiTestingApplication.class, args);
	}

}
