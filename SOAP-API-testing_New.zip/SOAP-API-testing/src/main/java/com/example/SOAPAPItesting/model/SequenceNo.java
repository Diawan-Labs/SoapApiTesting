package com.example.SOAPAPItesting.model;

public class SequenceNo {
	 int seqNo;

	public SequenceNo() {
		seqNo=101;
	}

	public SequenceNo(int seqNo) {
		super();
		this.seqNo = seqNo;
	}

	public int getSeqNo() {
		return seqNo;
	}

	public void setSeqNo(int seqNo) {
		this.seqNo = seqNo;
	}
    public void clear()
    {
    	seqNo = 0;
    }

    public void increment()
    {
    	seqNo++;
    }

    public String toString()
    {
        return ""+seqNo;
    }

	 
}
