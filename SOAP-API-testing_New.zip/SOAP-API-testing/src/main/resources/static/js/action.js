function demo()
{
	alert("this is an alert");
	}